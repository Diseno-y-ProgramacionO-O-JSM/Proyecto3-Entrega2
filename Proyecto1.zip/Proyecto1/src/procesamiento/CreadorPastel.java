package procesamiento;

import java.awt.Color;
import java.util.ArrayList;

import Intefaz.Slice;
import modelo.Actividad;
import modelo.Participante;

public class CreadorPastel {
	private Slice[] slices ;
	
	public CreadorPastel (){
		
		slices= new Slice[60]; 
		}
	public void cargarActividades(Participante elParticipante) {
		Color[] colores = {Color.blue,Color.green,Color.cyan,Color.red,Color.yellow,Color.black,Color.pink,Color.orange,Color.magenta};
		ArrayList<Actividad> actividades = elParticipante.getActividades(); 
		
		
		 
		for(int  i= 0; i < actividades.size(); i++) {
			
			Actividad act = actividades.get(i);
			slices[i]= new Slice(act.getTiempo(), colores[i]);
		}
	}
	public Slice[] darSlices(){
		return slices ;
	}
	
}

