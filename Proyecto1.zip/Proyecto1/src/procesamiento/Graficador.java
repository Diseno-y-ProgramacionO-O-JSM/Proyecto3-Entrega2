package procesamiento;

import java.awt.BorderLayout;

import javax.swing.JFrame;



import org.knowm.xchart.*;
import org.knowm.xchart.BitmapEncoder.BitmapFormat;




public class Graficador extends JFrame{

	public Graficador() {
		setLayout(new BorderLayout());

		setTitle("Proyectos 3000");

		setSize(620, 620);
		
		
	}
	
	
	
	public static DialChart getChart(String proy, double porc) {

		// Create Chart
		  DialChart chart = new DialChartBuilder().width(600).height(400).title("Calidad de Planeacion").build();

		  // Series
		  chart.addSeries("Calidad", porc, "Las tareas del primer tipo tienen un error mas grande de estimacion ");
		  chart.getStyler().setToolTipsEnabled(true);
		  chart.getStyler().setLegendVisible(false);

		  return chart;

		
		 }
	
	public static PieChart donut() {
		PieChart chart = new PieChartBuilder().width(500).height(300).title("Equipo").build();
		 
	    // Customize Chart
	    chart.getStyler().setLegendVisible(false);
	    
	    chart.getStyler().setPlotContentSize(.9);
	    // chart.getStyler().setCircular(false);
	 
	    // Series
	    chart.addSeries("A", 22);
	    chart.addSeries("B", 10);
	    chart.addSeries("C", 34);
	    chart.addSeries("D", 22);
	    chart.addSeries("E", 29);
	    chart.addSeries("F", 40);
	 
	    return chart;
	}
	
	
	public static void main(String[] args) {
		new Graficador();
	}
}
