package Intefaz;

import java.awt.Color;

public class Slice {
	double value;
	   Color color;
	   public Slice(double value, Color color) {
	      this.value = value;
	      this.color = color;
	   }
}
