package Intefaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;

import org.knowm.xchart.DialChart;
import org.knowm.xchart.PieChart;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.XChartPanel;

import consola.ControladorProyectos;
import modelo.Actividad;
import modelo.Proyecto;
import modelo.Tarea;
import procesamiento.CreadorPastel;
import procesamiento.Graficador;


public class Paneles extends JPanel implements ActionListener{

	ControladorProyectos controladorProyectos = new ControladorProyectos();

	private Ventana ventana;
	private JButton opcion1;
	private JButton opcion2;
	private JButton opcion3;
	private JButton opcion4;
	private JButton opcion5;
	private JButton opcion6;
	private JButton opcion7;
	private JButton opcion8;
	private JButton opcion9;
	private JButton opcion10;
	private JButton opcion11;

	
	private JPanel panel1;
	private JPanel panel2;
	private JPanel panel3;
	private JPanel panel4;
	private JPanel panel41;
	private JPanel panel42;
	private JPanel panel5;
	private JPanel panel51;
	private JPanel panel52;
	private JPanel panel6;
	private JPanel panel7;
	private JPanel panel8;
	private JPanel panel9;
	private JPanel panel91;
	private JPanel panel92;
	private JPanel panel10;
	private JPanel panel11;
	
	JTextField Nombre=new JTextField(20);
	JTextField Correo=new JTextField(20);
	JTextField Nombre1=new JTextField(20);
	JTextField Nombre7=new JTextField(20);
	JTextField Dueno=new JTextField(20);
	JTextField Proyecto=new JTextField(20);
	JTextField Actividades=new JTextField(20);
	JTextField Proyecto3=new JTextField(20);
	JTextField Participante3=new JTextField(20);
	JTextField Proyecto4=new JTextField(20);
	JComboBox<String> Tarea1;
	JComboBox<String> Tarea2;
	JTextField Actividad4=new JTextField(20);
	JTextField Participante4=new JTextField(20);
	JTextField Descripcion4=new JTextField(20);
	JComboBox<String> Tipo4;
	JTextField Participante8=new JTextField(20);
	JTextField Proyecto5=new JTextField(20);
	JTextField Actividad5=new JTextField(20);
	JTextField Participante5=new JTextField(20);
	JTextField Descripcion5=new JTextField(20);
	JTextField FechaIn5=new JTextField(20);
	JTextField FechaFin5=new JTextField(20);
	JTextField HoraInicio=new JTextField(20);
	JTextField HoraFin=new JTextField(20);
	JTextField Descripcion10=new JTextField(20);
	JTextField Descripcion11=new JTextField(20);
	JTextField Proyecto11=new JTextField(20);
	JComboBox<String> Tipo5;
	JTextField Tarea3=new JTextField(20);
	JTextField Paquete=new JTextField(20);
	JTextField Paquete10=new JTextField(20);
	JTextField Tareas11=new JTextField(20);
	JTextField Tarea12=new JTextField(20);
	JTextField Paquete13=new JTextField(20);
	JTextField Participante9=new JTextField(20);
	JComboBox<String> Jer;
	JTextField Proyecto10=new JTextField(20);
	JTextField Proyecto12=new JTextField(20);
	JTextField Proyecto13=new JTextField(20);
	JTextField Tareadel=new JTextField(20);
	JTextField FechaEstimada=new JTextField(20);
	JTextField Participante321=new JTextField(20);
	JTextField Proyecto321=new JTextField(20);

	
	public Paneles(Ventana ventana1) {
		
		this.ventana=ventana1;
		panel1 = new JPanel(new GridBagLayout());
		panel2 = new JPanel(new GridBagLayout());
		panel3 = new JPanel(new GridBagLayout());
		panel4 = new JPanel(new GridBagLayout());
		panel41 = new JPanel(new GridBagLayout());
		panel42 = new JPanel(new GridBagLayout());
		panel5 = new JPanel(new GridBagLayout());
		panel51 = new JPanel(new GridBagLayout());
		panel52 = new JPanel(new GridBagLayout());
		panel6 = new JPanel(new GridBagLayout());
		panel7 = new JPanel(new GridBagLayout());
		panel8 = new JPanel(new GridBagLayout());
		panel9 = new JPanel(new GridBagLayout());
		panel91 = new JPanel(new GridBagLayout());
		panel92 = new JPanel(new GridBagLayout());
		panel10 = new JPanel(new GridBagLayout());
		panel11 = new JPanel(new GridBagLayout());
		
		panel1.setBackground(Color.PINK);
		panel2.setBackground(Color.decode("#A9FFC6"));
		panel3.setBackground(Color.decode("#FFB67C"));
		panel4.setBackground(Color.decode("#A5CAE8"));
		panel41.setBackground(Color.decode("#A5CAE8"));
		panel42.setBackground(Color.decode("#A5CAE8"));
		panel5.setBackground(Color.decode("#FFF693"));
		panel51.setBackground(Color.decode("#FFF693"));
		panel52.setBackground(Color.decode("#FFF693"));
		panel6.setBackground(Color.decode("#B0FFFA"));
		panel7.setBackground(Color.decode("#BBBABF"));
		panel8.setBackground(Color.decode("#EB7E7B"));
		panel9.setBackground(Color.decode("#70D5D3"));
		panel91.setBackground(Color.decode("#70D5D3"));
		panel92.setBackground(Color.decode("#70D5D3"));
		panel10.setBackground(Color.decode("#70D5D3"));
		panel11.setBackground(Color.ORANGE);

		
		
		opcion1 = new JButton("Registrar Usuario");
		opcion1.addActionListener(this);
		opcion2 = new JButton("Crear Proyecto");
		opcion2.addActionListener(this);
		opcion3 = new JButton("Agregar Participante");
		opcion3.addActionListener(this);
		opcion4 = new JButton("Iniciar Actividad");
		opcion4.addActionListener(this);
		opcion5 = new JButton("Registrar Actividad");
		opcion5.addActionListener(this);
		opcion6 = new JButton("Finalizar Actividad");
		opcion6.addActionListener(this);
		opcion7 = new JButton("Finalizar Proyecto");
		opcion7.addActionListener(this);
		opcion8 = new JButton("Reporte Usuario");
		opcion8.addActionListener(this);
		opcion9 = new JButton("Admin Tareas");
		opcion9.addActionListener(this);
		opcion10 = new JButton("Agregar Tareas");
		opcion10.addActionListener(this);
		opcion11 = new JButton("Visualizaciones");
		opcion11.addActionListener(this);
	
		this.setLayout(new GridLayout(11, 1));

		this.add(opcion1);
		this.add(opcion2);
		this.add(opcion3);
		this.add(opcion10);
		this.add(opcion9);
		this.add(opcion4);
		this.add(opcion5);
		this.add(opcion6);
		this.add(opcion7);
		this.add(opcion8);
		this.add(opcion11);

		
		
		ventana.add(this,BorderLayout.WEST);

		
	}

	@SuppressWarnings("unchecked")
	@Override
	public void actionPerformed(ActionEvent e) {
		Object event = e.getActionCommand();
		String[] strAr3 = null;
		String[] strAr4 = null;

		Instant tiempo = null;
		
		if (event.equals("Registrar Usuario")) {

			ventana.getContentPane().removeAll();

			JLabel nombre = new JLabel("Nombre:");
			JLabel correo = new JLabel("Correo:");
			JLabel info = new JLabel(" Registrar usuario \t        ");

			Font font = new Font("MS Sans Serif", Font.BOLD, 22);
			info.setFont(font);

			JButton boton = new JButton("Registrar");
			boton.addActionListener(this);
			GridBagConstraints constraints = new GridBagConstraints();
			constraints.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints.insets = new Insets(10, 10, 10, 10);

			constraints.gridx = 1;
			constraints.gridy = 0;
			panel1.add(info, constraints);

			constraints.gridx = 0;
			constraints.gridy = 1;
			panel1.add(nombre, constraints);

			constraints.gridx = 1;
			constraints.gridy = 1;
			panel1.add(Nombre, constraints);

			constraints.gridx = 0;
			constraints.gridy = 2;
			panel1.add(correo, constraints);

			constraints.gridx = 1;
			constraints.gridy = 2;
			panel1.add(Correo, constraints);

			constraints.gridx = 0;
			constraints.gridy = 3;
			constraints.gridwidth = 2;
			constraints.anchor = GridBagConstraints.CENTER;
			panel1.add(boton, constraints);

			ventana.getContentPane().add(panel1, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();

		} else if (event.equals("Crear Proyecto")) {

			ventana.getContentPane().removeAll();
			
			enableDefaultValue(Actividades, "Actividad1,Actividad2,Actividad3...");


			JLabel nombre1 = new JLabel("Nombre proyecto:");
			JLabel dueno = new JLabel("Due�o:");
			JLabel proyecto = new JLabel("Descripcion:");
			JLabel actividades = new JLabel("Actividades:");
			JLabel info1 = new JLabel(" Crear proyecto \t        ");

			Font font1 = new Font("MS Sans Serif", Font.BOLD, 22);
			info1.setFont(font1);

			JButton boton1 = new JButton("Crear");
			boton1.addActionListener(this);
			GridBagConstraints constraints1 = new GridBagConstraints();
			constraints1.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints1.insets = new Insets(10, 10, 10, 10);

			constraints1.gridx = 1;
			constraints1.gridy = 0;
			panel2.add(info1, constraints1);

			constraints1.gridx = 0;
			constraints1.gridy = 1;
			panel2.add(nombre1, constraints1);

			constraints1.gridx = 1;
			constraints1.gridy = 1;
			panel2.add(Nombre1, constraints1);

			constraints1.gridx = 1;
			constraints1.gridy = 2;
			panel2.add(Dueno, constraints1);

			constraints1.gridx = 0;
			constraints1.gridy = 2;
			panel2.add(dueno, constraints1);

			constraints1.gridx = 1;
			constraints1.gridy = 3;
			panel2.add(Proyecto, constraints1);

			constraints1.gridx = 0;
			constraints1.gridy = 3;
			panel2.add(proyecto, constraints1);

			constraints1.gridx = 1;
			constraints1.gridy = 4;
			panel2.add(Actividades, constraints1);

			constraints1.gridx = 0;
			constraints1.gridy = 4;
			panel2.add(actividades, constraints1);

			constraints1.gridx = 0;
			constraints1.gridy = 5;
			constraints1.gridwidth = 2;
			constraints1.anchor = GridBagConstraints.CENTER;
			panel2.add(boton1, constraints1);
			ventana.getContentPane().add(panel2, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();

		} else if (event.equals("Agregar Participante")) {

			ventana.getContentPane().removeAll();

			JLabel proyecto3 = new JLabel("Nombre Proyecto:");
			JLabel participante3 = new JLabel("Nombre Participante:");
			JLabel info3 = new JLabel(" Agregar Participante \t  ");

			Font font3 = new Font("MS Sans Serif", Font.BOLD, 22);
			info3.setFont(font3);

			JButton boton3 = new JButton("Agregar");
			boton3.addActionListener(this);
			GridBagConstraints constraints3 = new GridBagConstraints();
			constraints3.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints3.insets = new Insets(10, 10, 10, 10);

			constraints3.gridx = 1;
			constraints3.gridy = 0;
			panel3.add(info3, constraints3);

			constraints3.gridx = 0;
			constraints3.gridy = 1;
			panel3.add(proyecto3, constraints3);

			constraints3.gridx = 1;
			constraints3.gridy = 1;
			panel3.add(Proyecto3, constraints3);

			constraints3.gridx = 0;
			constraints3.gridy = 2;
			panel3.add(participante3, constraints3);

			constraints3.gridx = 1;
			constraints3.gridy = 2;
			panel3.add(Participante3, constraints3);

			constraints3.gridx = 0;
			constraints3.gridy = 3;
			constraints3.gridwidth = 2;
			constraints3.anchor = GridBagConstraints.CENTER;
			panel3.add(boton3, constraints3);
			ventana.getContentPane().add(panel3, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();

		} else if (event.equals("Iniciar Actividad")) {

			ventana.getContentPane().removeAll();
			
			Tipo4 = new javax.swing.JComboBox<String>(new String[] {"Opciones..."}) ;
			Tarea1 = new javax.swing.JComboBox<String>(new String[] {"Opciones..."});
			
			JLabel proyecto4 = new JLabel("Nombre proyecto:");
			JLabel actividad4 = new JLabel("Nombre Actividad:");
			JLabel participante4 = new JLabel("Participante:");
			JLabel descripcion4 = new JLabel("Descripcion:");
			JLabel tipo4 = new JLabel("Tipo:");
			JLabel tarea1 = new JLabel("Tarea:");

			JLabel info4 = new JLabel("Iniciar Actividad");

			Font font4 = new Font("MS Sans Serif", Font.BOLD, 22);
			info4.setFont(font4);

			JButton boton4 = new JButton("Iniciar");
			boton4.addActionListener(this);

			JButton boton44 = new JButton("Verificar");
			boton44.addActionListener(this);

			GridBagConstraints constraints4 = new GridBagConstraints();
			constraints4.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints4.insets = new Insets(10, 10, 10, 10);

			constraints4.gridx = 1;
			constraints4.gridy = 0;
			constraints4.anchor = GridBagConstraints.CENTER;
			panel4.add(info4, constraints4);

			constraints4.gridx = 0;
			constraints4.gridy = 1;
			panel4.add(proyecto4, constraints4);

			constraints4.gridx = 1;
			constraints4.gridy = 1;
			panel4.add(Proyecto4, constraints4);

			constraints4.gridx = 1;
			constraints4.gridy = 4;
			panel4.add(Actividad4, constraints4);

			constraints4.gridx = 0;
			constraints4.gridy = 4;
			panel4.add(actividad4, constraints4);

			constraints4.gridx = 1;
			constraints4.gridy = 5;
			panel4.add(Participante4, constraints4);

			constraints4.gridx = 0;
			constraints4.gridy = 5;
			panel4.add(participante4, constraints4);

			constraints4.gridx = 1;
			constraints4.gridy = 6;
			panel4.add(Descripcion4, constraints4);

			constraints4.gridx = 0;
			constraints4.gridy = 6;
			panel4.add(descripcion4, constraints4);

			constraints4.gridx = 1;
			constraints4.gridy = 7;
			constraints4.anchor = GridBagConstraints.CENTER;
			panel4.add(Tipo4, constraints4);

			constraints4.gridx = 0;
			constraints4.gridy = 7;
			panel4.add(tipo4, constraints4);

			constraints4.gridx = 1;
			constraints4.gridy = 8;
			constraints4.anchor = GridBagConstraints.CENTER;
			panel4.add(Tarea1, constraints4);

			constraints4.gridx = 0;
			constraints4.gridy = 8;
			panel4.add(tarea1, constraints4);
			
			constraints4.gridx = 0;
			constraints4.gridy = 3;
			constraints4.gridwidth = 2;
			constraints4.anchor = GridBagConstraints.CENTER;

			panel4.add(boton44, constraints4);
			constraints4.gridx = 0;
			constraints4.gridy = 9;
			constraints4.gridwidth = 2;
			constraints4.anchor = GridBagConstraints.CENTER;

			panel4.add(boton4, constraints4);

			ventana.getContentPane().add(panel4, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();

		} else if (event.equals("Registrar Actividad")) {

			
			ventana.getContentPane().removeAll();
			
			Tipo5 = new javax.swing.JComboBox<String>(new String[] {"Opciones..."});
			
			Tarea2 = new javax.swing.JComboBox<String>(new String[] {"Opciones..."});
			enableDefaultValue(HoraFin, "HH:mm:");
			enableDefaultValue(HoraInicio, "HH:mm");
			enableDefaultValue(FechaIn5, "dd-MM-yyyy");
			enableDefaultValue(FechaFin5, "dd-MM-yyyy");
			JLabel proyecto5 = new JLabel("Nombre proyecto:");
			JLabel actividad5 = new JLabel("Nombre Actividad:");
			JLabel participante5 = new JLabel("Participante:");
			JLabel descripcion5 = new JLabel("Descripcion:");
			JLabel fechain5 = new JLabel("Fecha Inicio:");
			JLabel fechafin5 = new JLabel("Fecha Fin:");
			JLabel horain = new JLabel("Hora Inicio:");
			JLabel horafin = new JLabel("Hora Fin:");
			JLabel tipo5 = new JLabel("Tipo:");
			JLabel tarea2 = new JLabel("Tarea:");

			JLabel info5 = new JLabel("Registrar Actividad");

			Font font5 = new Font("MS Sans Serif", Font.BOLD, 22);
			info5.setFont(font5);

			JButton boton5 = new JButton("Registrar  ");
			boton5.addActionListener(this);

			JButton boton55 = new JButton("Verificar ");
			boton55.addActionListener(this);

			GridBagConstraints constraints5 = new GridBagConstraints();
			constraints5.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints5.insets = new Insets(10, 10, 10, 10);

			constraints5.gridx = 1;
			constraints5.gridy = 0;
			constraints5.anchor = GridBagConstraints.CENTER;
			panel5.add(info5, constraints5);

			constraints5.gridx = 0;
			constraints5.gridy = 1;
			panel5.add(proyecto5, constraints5);

			constraints5.gridx = 1;
			constraints5.gridy = 1;
			panel5.add(Proyecto5, constraints5);

			constraints5.gridx = 1;
			constraints5.gridy = 4;
			panel5.add(Actividad5, constraints5);

			constraints5.gridx = 0;
			constraints5.gridy = 4;
			panel5.add(actividad5, constraints5);

			constraints5.gridx = 1;
			constraints5.gridy = 5;
			panel5.add(Participante5, constraints5);

			constraints5.gridx = 0;
			constraints5.gridy = 5;
			panel5.add(participante5, constraints5);

			constraints5.gridx = 1;
			constraints5.gridy = 6;
			panel5.add(Descripcion5, constraints5);

			constraints5.gridx = 0;
			constraints5.gridy = 6;
			panel5.add(descripcion5, constraints5);

			constraints5.gridx = 1;
			constraints5.gridy = 7;
			constraints5.anchor = GridBagConstraints.CENTER;
			panel5.add(Tipo5, constraints5);

			constraints5.gridx = 0;
			constraints5.gridy = 7;
			panel5.add(tipo5, constraints5);
			
			constraints5.gridx = 1;
			constraints5.gridy = 8;
			panel5.add(FechaIn5, constraints5);

			constraints5.gridx = 0;
			constraints5.gridy = 8;
			panel5.add(fechain5, constraints5);
			constraints5.gridx = 1;
			constraints5.gridy = 9;
			panel5.add(FechaFin5, constraints5);

			constraints5.gridx = 0;
			constraints5.gridy = 9;
			panel5.add(fechafin5, constraints5);
			
			constraints5.gridx = 1;
			constraints5.gridy = 10;
			panel5.add(HoraInicio, constraints5);
			constraints5.gridx = 0;
			constraints5.gridy = 10;
			panel5.add(horain, constraints5);
			constraints5.gridx = 0;
			constraints5.gridy = 11;
			panel5.add(horafin, constraints5);
			constraints5.gridx = 1;
			constraints5.gridy = 11;
			panel5.add(HoraFin, constraints5);

			constraints5.gridx = 1;
			constraints5.gridy = 12;
			constraints5.anchor = GridBagConstraints.CENTER;
			panel5.add(Tarea2, constraints5);

			constraints5.gridx = 0;
			constraints5.gridy = 12;
			panel5.add(tarea2, constraints5);
			
			constraints5.gridx = 0;
			constraints5.gridy = 3;
			constraints5.gridwidth = 2;
			constraints5.anchor = GridBagConstraints.CENTER;

			panel5.add(boton55, constraints5);
			constraints5.gridx = 0;
			constraints5.gridy = 13;
			constraints5.gridwidth = 2;
			constraints5.anchor = GridBagConstraints.CENTER;

			panel5.add(boton5, constraints5);

			
			
			ventana.getContentPane().add(panel5, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();

		} else if (event.equals("Finalizar Actividad")) {

			ventana.getContentPane().removeAll();
			JLabel titulo6 = new JLabel("Finalizar actividad");

			Font font6 = new Font("MS Sans Serif", Font.BOLD, 22);
			
			titulo6.setFont(font6);

			JButton boton6 = new JButton("Finalizar actividad en curso");
			boton6.addActionListener(this);
			GridBagConstraints constraints6 = new GridBagConstraints();
			constraints6.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints6.insets = new Insets(10, 10, 10, 10);
			constraints6.gridx = 0;
			constraints6.gridy = 3;
			constraints6.gridwidth = 2;
			constraints6.anchor = GridBagConstraints.CENTER;
			panel6.add(boton6, constraints6);

			constraints6.gridx = 1;
			constraints6.gridy = 0;
			constraints6.gridwidth = 2;
			constraints6.anchor = GridBagConstraints.CENTER;
			panel6.add(titulo6, constraints6);
			ventana.getContentPane().add(panel6, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();

		} else if (event.equals("Finalizar Proyecto")) {

			ventana.getContentPane().removeAll();
			JLabel titulo7 = new JLabel("Finalizar proyecto");
			Font font7 = new Font("MS Sans Serif", Font.BOLD, 22);
			titulo7.setFont(font7);
			JLabel nombre7 = new JLabel("Nombre del proyecto: ");
		

			JButton boton7 = new JButton("Finalizar proyecto");
			boton7.addActionListener(this);
			GridBagConstraints constraints7 = new GridBagConstraints();
			constraints7.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints7.insets = new Insets(10, 10, 10, 10);

			constraints7.gridx = 1;
			constraints7.gridy = 0;
			constraints7.anchor = GridBagConstraints.CENTER;

			panel7.add(titulo7, constraints7);

			constraints7.gridx = 0;
			constraints7.gridy = 1;
			panel7.add(nombre7, constraints7);

			constraints7.gridx = 1;
			constraints7.gridy = 1;
			panel7.add(Nombre7, constraints7);

			constraints7.gridx = 0;
			constraints7.gridy = 3;
			constraints7.gridwidth = 2;
			constraints7.anchor = GridBagConstraints.CENTER;
			panel7.add(boton7, constraints7);
			ventana.getContentPane().add(panel7, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();

		} 
		else if (event.equals("Reporte Usuario")) {

			ventana.getContentPane().removeAll();

			JLabel participante8 = new JLabel("Nombre Participante:");

			JLabel info8 = new JLabel(" Reporte usuario \t  ");

			Font font8 = new Font("MS Sans Serif", Font.BOLD, 22);
			info8.setFont(font8);

			JButton boton8 = new JButton("Generar");
			boton8.addActionListener(this);
			GridBagConstraints constraints8 = new GridBagConstraints();
			constraints8.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints8.insets = new Insets(10, 10, 10, 10);

			constraints8.gridx = 1;
			constraints8.gridy = 0;
			panel8.add(info8, constraints8);

			constraints8.gridx = 0;
			constraints8.gridy = 2;
			panel8.add(participante8, constraints8);

			constraints8.gridx = 1;
			constraints8.gridy = 2;
			panel8.add(Participante8, constraints8);

			constraints8.gridx = 0;
			constraints8.gridy = 3;
			constraints8.gridwidth = 2;
			constraints8.anchor = GridBagConstraints.CENTER;
			panel8.add(boton8, constraints8);

			ventana.getContentPane().add(panel8, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();
			}
		
		else if (event.equals("Agregar Tareas")) {
			ventana.getContentPane().removeAll();

			JLabel tarea3 = new JLabel("Nombre de la Tarea:");
			JLabel descripcion10 = new JLabel("Descripcion:");
			JLabel descripcion11 = new JLabel("Descripcion:");
			JLabel proyecto11 = new JLabel("Proyecto:");
			JLabel jer = new JLabel("Importancia:");
			JLabel paquete10 = new JLabel("Nombre del Paquete:");
			JLabel proyecto10 = new JLabel("Proyecto:");
			JButton boton10 = new JButton("Crear Tarea");
			boton10.addActionListener(this);
			JButton boton11 = new JButton("Crear Paquete");
			boton11.addActionListener(this);
			JLabel info10 = new JLabel(" Crear Tareas \t  ");
			JLabel info11 = new JLabel(" Crear Paquetes \t  ");
			
			enableDefaultValue(Paquete, "Tarea1,Tarea2,Tarea3,...");
			Jer = new javax.swing.JComboBox<String>(new String[] {"Baja","Media","Alta",});

			Font font8 = new Font("MS Sans Serif", Font.BOLD, 22);
			info10.setFont(font8);
			info11.setFont(font8);
			
			GridBagConstraints constraints10 = new GridBagConstraints();
			constraints10.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints10.insets = new Insets(10, 10, 10, 10);
			

			constraints10.gridx = 1;
			constraints10.gridy = 0;
			constraints10.anchor = GridBagConstraints.CENTER;
			panel10.add(info10, constraints10);
			
			constraints10.gridx = 0;
			constraints10.gridy = 2;
			panel10.add(tarea3, constraints10);

			constraints10.gridx = 1;
			constraints10.gridy = 2;
			panel10.add(Tarea3, constraints10);
			
			constraints10.gridx = 0;
			constraints10.gridy = 3;
			panel10.add(descripcion10, constraints10);

			constraints10.gridx = 1;
			constraints10.gridy = 3;
			panel10.add(Descripcion10, constraints10);
			
			constraints10.gridx = 1;
			constraints10.gridy = 4;
			constraints10.anchor = GridBagConstraints.CENTER;
			panel10.add(Jer, constraints10);

			constraints10.gridx = 0;
			constraints10.gridy = 4;
			panel10.add(jer, constraints10);
			
			constraints10.gridx = 0;
			constraints10.gridy = 5;
			panel10.add(proyecto10, constraints10);

			constraints10.gridx = 1;
			constraints10.gridy = 5;
			panel10.add(Proyecto10, constraints10);
			
			
			constraints10.gridx = 1;
			constraints10.gridy = 7;
			constraints10.anchor = GridBagConstraints.CENTER;
			panel10.add(info11, constraints10);
			
			constraints10.gridx = 0;
			constraints10.gridy = 8;
			panel10.add(paquete10, constraints10);

			constraints10.gridx = 1;
			constraints10.gridy = 8;
			panel10.add(Paquete10, constraints10);
			
			constraints10.gridx = 0;
			constraints10.gridy = 9;
			panel10.add(descripcion11, constraints10);

			constraints10.gridx = 1;
			constraints10.gridy = 9;
			panel10.add(Descripcion11, constraints10);
			
			constraints10.gridx = 0;
			constraints10.gridy = 10;
			panel10.add(proyecto11, constraints10);

			constraints10.gridx = 1;
			constraints10.gridy = 10;
			panel10.add(Proyecto11, constraints10);
						
			constraints10.gridx = 0;
			constraints10.gridy = 12;
			constraints10.gridwidth = 2;
			constraints10.anchor = GridBagConstraints.CENTER;
			panel10.add(boton11, constraints10);
			
			constraints10.gridx = 0;
			constraints10.gridy = 6;
			constraints10.gridwidth = 2;
			constraints10.anchor = GridBagConstraints.CENTER;
			panel10.add(boton10, constraints10);

			ventana.getContentPane().add(panel10, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();
			
		}
		else if (event.equals("Admin Tareas")) {
			ventana.getContentPane().removeAll();
////////	
			JLabel tareas11 = new JLabel("Tareas:");
			JLabel tarea12 = new JLabel("Tarea:");
			JLabel paquete13 = new JLabel("Paquete:");
			JLabel participante9 = new JLabel("Responsable:");
			JLabel fechaestimada = new JLabel("Fecha estimada:");
			enableDefaultValue(FechaEstimada,"dd-MM-yyyy");
			
			JLabel info12 = new JLabel(" Administrar tareas \t  ");
			JLabel info13 = new JLabel(" Asignar responsable a una tarea \t  ");
			JLabel info14 = new JLabel(" Agregar tareas a un paquete\t  ");

			JLabel info16= new JLabel(" Asignar fecha de finalizacion\t  ");


			Font font9 = new Font("MS Sans Serif", Font.BOLD, 22);
			JButton boton12 = new JButton("Asignar");
			boton12.addActionListener(this);
			JButton boton13 = new JButton("Empaquetar");
			boton13.addActionListener(this);
			JButton boton14 = new JButton("Eliminar");
			boton14.addActionListener(this);
			JButton boton15 = new JButton("Ok");
			boton15.addActionListener(this);
			JButton boton16 = new JButton(" Verificar Tarea");
			boton16.addActionListener(this);
		
			info12.setFont(font9);
			
			GridBagConstraints constraints11 = new GridBagConstraints();
			constraints11.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints11.insets = new Insets(10, 10, 10, 10);	
			
			constraints11.gridx = 1;
			constraints11.gridy = 0;
			panel9.add(info12, constraints11);
			
			constraints11.gridx = 0;
			constraints11.gridy = 2;
			panel9.add(tarea12, constraints11);
			
			constraints11.gridx = 1;
			constraints11.gridy = 2;
			panel9.add(Tarea12, constraints11);
			
			//Boton verificar y eliminar
			
			constraints11.gridx = 0;
			constraints11.gridy = 3;
			constraints11.gridwidth = 1;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel9.add(boton16, constraints11);
			
			constraints11.gridx = 1;
			constraints11.gridy = 3;
			constraints11.gridwidth = 1;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel9.add(boton14, constraints11);
			
			//Asignar responsable			

			constraints11.gridx = 1;
			constraints11.gridy = 4;
			panel9.add(info13, constraints11);
			
			constraints11.gridx = 0;
			constraints11.gridy = 5;
			panel9.add(participante9, constraints11);

			constraints11.gridx = 1;
			constraints11.gridy = 5;
			panel9.add(Participante9, constraints11);
			
			//Asignar fecha
			
			constraints11.gridx = 0;
			constraints11.gridy = 8;
			panel9.add(fechaestimada, constraints11);

			constraints11.gridx = 1;
			constraints11.gridy = 8 ;
			panel9.add(FechaEstimada, constraints11);
	
			///Empaquetar
			
			constraints11.gridx = 0;
			constraints11.gridy = 11;
			panel9.add(paquete13, constraints11);

			constraints11.gridx = 1;
			constraints11.gridy = 11;
			panel9.add(Paquete13, constraints11);
			
			constraints11.gridx = 0;
			constraints11.gridy = 12;
			panel9.add(tareas11, constraints11);

			constraints11.gridx = 1;
			constraints11.gridy = 12;
			panel9.add(Tareas11, constraints11);
			
			
			constraints11.gridx = 0;
			constraints11.gridy = 13;
			constraints11.gridwidth = 2;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel9.add(boton13, constraints11);
				
			////Textos
			
			constraints11.gridx = 0;
			constraints11.gridy = 6;
			constraints11.gridwidth = 2;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel9.add(boton12, constraints11);
			
			constraints11.gridx = 0;
			constraints11.gridy = 9;
			constraints11.gridwidth = 2;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel9.add(boton15, constraints11);
			
			constraints11.gridx = 1;
			constraints11.gridy = 7;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel9.add(info16, constraints11);
			
			constraints11.gridx = 1;
			constraints11.gridy = 10;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel9.add(info14, constraints11);
			
			
			ventana.getContentPane().add(panel9, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();
			
		}
		else if (event.equals(" Verificar Tarea")) {
			String t = Tarea12.getText();
			HashMap<String, Tarea> tareas = controladorProyectos.getTareas();
			
			Tarea tarea = tareas.get(t);
			
			if(tarea!=null) {
				
				ventana.getContentPane().removeAll();
		
				JLabel tareas11 = new JLabel("Tareas:");
				JLabel paquete13 = new JLabel("Paquete:");
				JLabel participante9 = new JLabel("Responsable:");
				JLabel fechaestimada = new JLabel("Fecha estimada:");
				enableDefaultValue(FechaEstimada,"dd-MM-yyyy");
				
				JLabel info12 = new JLabel(" Administrar tareas \t  ");
				JLabel info13 = new JLabel(" Asignar responsable a una tarea \t  ");
				JLabel info14 = new JLabel(" Agregar tareas a un paquete\t  ");
				JLabel info16= new JLabel(" Asignar fecha de finalizacion\t  ");
				JLabel info17 = new JLabel(" Se ha encontrado la tarea exitosamente\t  ");

				Font font9 = new Font("MS Sans Serif", Font.BOLD, 22);
				JButton boton12 = new JButton("Asignar");
				boton12.addActionListener(this);
				JButton boton13 = new JButton("Empaquetar");
				boton13.addActionListener(this);
				JButton boton14 = new JButton("Eliminar");
				boton14.addActionListener(this);
				JButton boton15 = new JButton("Ok");
				boton15.addActionListener(this);
				JButton boton16 = new JButton(" Verificar Tarea");
				boton16.addActionListener(this);
			
				info12.setFont(font9);
				
				GridBagConstraints constraints11 = new GridBagConstraints();
				constraints11.anchor = GridBagConstraints.FIRST_LINE_END;
				constraints11.insets = new Insets(10, 10, 10, 10);	
				
				constraints11.gridx = 1;
				constraints11.gridy = 0;
				panel91.add(info12, constraints11);
				
				constraints11.gridx = 1;
				constraints11.gridy = 2;
				panel91.add(info17, constraints11);
				
			
				//Boton eliminar
				
				constraints11.gridx = 1;
				constraints11.gridy = 3;
				constraints11.gridwidth = 1;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel91.add(boton14, constraints11);
				
				//Asignar responsable			

				constraints11.gridx = 1;
				constraints11.gridy = 4;
				panel91.add(info13, constraints11);
				
				constraints11.gridx = 0;
				constraints11.gridy = 5;
				panel91.add(participante9, constraints11);

				constraints11.gridx = 1;
				constraints11.gridy = 5;
				panel91.add(Participante9, constraints11);
				
				//Asignar fecha
				
				constraints11.gridx = 0;
				constraints11.gridy = 8;
				panel91.add(fechaestimada, constraints11);

				constraints11.gridx = 1;
				constraints11.gridy = 8 ;
				panel91.add(FechaEstimada, constraints11);
		
				///Empaquetar
				
				constraints11.gridx = 0;
				constraints11.gridy = 11;
				panel91.add(paquete13, constraints11);

				constraints11.gridx = 1;
				constraints11.gridy = 11;
				panel91.add(Paquete13, constraints11);
				
				constraints11.gridx = 0;
				constraints11.gridy = 12;
				panel91.add(tareas11, constraints11);

				constraints11.gridx = 1;
				constraints11.gridy = 12;
				panel91.add(Tareas11, constraints11);
				
				
				constraints11.gridx = 0;
				constraints11.gridy = 13;
				constraints11.gridwidth = 2;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel91.add(boton13, constraints11);				
				
				////Textos
				
				constraints11.gridx = 0;
				constraints11.gridy = 6;
				constraints11.gridwidth = 2;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel91.add(boton12, constraints11);
				
				constraints11.gridx = 0;
				constraints11.gridy = 9;
				constraints11.gridwidth = 2;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel91.add(boton15, constraints11);
				
				constraints11.gridx = 1;
				constraints11.gridy = 7;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel91.add(info16, constraints11);
				
				constraints11.gridx = 1;
				constraints11.gridy = 10;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel91.add(info14, constraints11);
				
				ventana.getContentPane().add(panel91, BorderLayout.CENTER);
				ventana.getContentPane().add(this, BorderLayout.WEST);
				ventana.getContentPane().revalidate();
				ventana.getContentPane().repaint();
			}
			else {
				ventana.getContentPane().removeAll();
				JLabel info17 = new JLabel(" No se ha encontrado la tarea\t  ");

				JLabel tareas11 = new JLabel("Tareas:");
				JLabel tarea12 = new JLabel("Tarea:");
				JLabel paquete13 = new JLabel("Paquete:");
				JLabel participante9 = new JLabel("Responsable:");
				JLabel fechaestimada = new JLabel("Fecha estimada:");
				enableDefaultValue(FechaEstimada,"dd-MM-yyyy");
				
				JLabel info12 = new JLabel(" Administrar tareas \t  ");
				JLabel info13 = new JLabel(" Asignar responsable a una tarea \t  ");
				JLabel info14 = new JLabel(" Agregar tareas a un paquete\t  ");

				JLabel info16= new JLabel(" Asignar fecha de finalizacion\t  ");


				Font font9 = new Font("MS Sans Serif", Font.BOLD, 22);
				JButton boton12 = new JButton("Asignar");
				boton12.addActionListener(this);
				JButton boton13 = new JButton("Empaquetar");
				boton13.addActionListener(this);
				JButton boton14 = new JButton("Eliminar");
				boton14.addActionListener(this);
				JButton boton15 = new JButton("Ok");
				boton15.addActionListener(this);
				JButton boton16 = new JButton(" Verificar Tarea");
				boton16.addActionListener(this);
			
				info12.setFont(font9);
				
				GridBagConstraints constraints11 = new GridBagConstraints();
				constraints11.anchor = GridBagConstraints.FIRST_LINE_END;
				constraints11.insets = new Insets(10, 10, 10, 10);	
				
				constraints11.gridx = 1;
				constraints11.gridy = 0;
				panel92.add(info12, constraints11);
				
				constraints11.gridx = 1;
				constraints11.gridy = 2;
				panel92.add(info17, constraints11);
				
				constraints11.gridx = 0;
				constraints11.gridy = 3;
				panel92.add(tarea12, constraints11);
				
				constraints11.gridx = 1;
				constraints11.gridy = 3;
				panel92.add(Tarea12, constraints11);
				
				//Boton verificar y eliminar
				
				constraints11.gridx = 0;
				constraints11.gridy = 4;
				constraints11.gridwidth = 1;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel92.add(boton16, constraints11);
				
				constraints11.gridx = 1;
				constraints11.gridy = 4;
				constraints11.gridwidth = 1;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel92.add(boton14, constraints11);
				
				//Asignar responsable			

				constraints11.gridx = 1;
				constraints11.gridy = 5;
				panel92.add(info13, constraints11);
				
				constraints11.gridx = 0;
				constraints11.gridy = 6;
				panel92.add(participante9, constraints11);

				constraints11.gridx = 1;
				constraints11.gridy = 6;
				panel92.add(Participante9, constraints11);
				
				//Asignar fecha
				
				constraints11.gridx = 0;
				constraints11.gridy = 9;
				panel92.add(fechaestimada, constraints11);

				constraints11.gridx = 1;
				constraints11.gridy = 9 ;
				panel92.add(FechaEstimada, constraints11);
								
				///Empaquetar
				
				constraints11.gridx = 0;
				constraints11.gridy = 12;
				panel92.add(paquete13, constraints11);

				constraints11.gridx = 1;
				constraints11.gridy = 12;
				panel92.add(Paquete13, constraints11);
				
				constraints11.gridx = 0;
				constraints11.gridy = 13;
				panel92.add(tareas11, constraints11);

				constraints11.gridx = 1;
				constraints11.gridy = 13;
				panel92.add(Tareas11, constraints11);
				
				
				constraints11.gridx = 0;
				constraints11.gridy = 14;
				constraints11.gridwidth = 2;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel92.add(boton13, constraints11);
						
				////Textos
				
				constraints11.gridx = 0;
				constraints11.gridy = 7;
				constraints11.gridwidth = 2;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel92.add(boton12, constraints11);
				
				constraints11.gridx = 0;
				constraints11.gridy = 10;
				constraints11.gridwidth = 2;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel92.add(boton15, constraints11);
				
				constraints11.gridx = 1;
				constraints11.gridy = 8;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel92.add(info16, constraints11);
				
				constraints11.gridx = 1;
				constraints11.gridy = 11;
				constraints11.anchor = GridBagConstraints.CENTER;
				panel92.add(info14, constraints11);
				
				Tareas11.setText("");			
				Paquete13.setText("");
				Tarea12.setText("");
				Participante9.setText("");
				FechaEstimada.setText("");
				
				ventana.getContentPane().add(panel92, BorderLayout.CENTER);
				ventana.getContentPane().add(this, BorderLayout.WEST);
				ventana.getContentPane().revalidate();
				ventana.getContentPane().repaint();
				
			}
			
		}
		else if (event.equals("Crear Tarea")) {

			String name = Tarea3.getText();
			String descripcion = Descripcion10.getText(); 
			String proy = Proyecto10.getText();
			String importancia = (String) Jer.getSelectedItem();
			
			
			controladorProyectos.CrearTarea(name, proy, descripcion, importancia);
			
			Tarea3.setText("");
			Descripcion10.setText("");
			Jer.setSelectedItem(null);
			Proyecto10.setText("");			
		}
		
		else if (event.equals("Crear Paquete")) {

			String name = Paquete10.getText();
			String desc = Descripcion11.getText();
			String proy = Proyecto11.getText();	
			
			
			controladorProyectos.CrearPaquete(name,desc, proy);
			
			Paquete10.setText("");
			Descripcion11.setText("");
			Proyecto11.setText("");
			
		}
		
		else if (event.equals("Empaquetar")) {

			String name = Paquete13.getText();
			String tareas = Tareas11.getText();
			
/////////////////		
			controladorProyectos.addTPaquete(name, tareas);
			
			Paquete13.setText("");
			Tareas11.setText("");
			
		}
		
		else if (event.equals("Asignar")) {

			String tarea = Tarea12.getText();
			String responsable = Participante9.getText();
			

			controladorProyectos.addResponsable(responsable, tarea);
			
			Tarea12.setText("");
			Participante9.setText("");
			
		}
		
		else if (event.equals("Eliminar")) {

			String tarea = Tarea12.getText();	
			
			controladorProyectos.delete(tarea);
			
			Tarea12.setText("");
			
			
		}
		
		else if (event.equals("Ok")) {
			String fecha = FechaEstimada.getText();
			String tarea = Tarea12.getText();
			controladorProyectos.asignarFecha(tarea,fecha);
			FechaEstimada.setText("");
			Tarea12.setText("");
		}
		
		else if (event.equals("Registrar")) {

			String name = Nombre.getText();
			String mail = Correo.getText();
			
			controladorProyectos.RegistroUsuario(name, mail);
			
			Nombre.setText("");
			Correo.setText("");
			
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();

		} else if (event.equals("Crear")) {

			String name = Nombre1.getText();
			String dueno = Dueno.getText();
			String proyecto = Proyecto.getText();
			String actividades = Actividades.getText();
			controladorProyectos.CrearProyecto(name, dueno, proyecto, actividades);
			Nombre1.setText(null);
			Dueno.setText(null);
			Proyecto.setText(null);
			Actividades.setText(null);

		} else if (event.equals("Agregar")) {

			String name = Proyecto3.getText();
			String dueno = Participante3.getText();
			controladorProyectos.AgregarParticipante(name, dueno);
			Proyecto3.setText(null);
			Participante3.setText(null);

		}

		else if (event.equals("Verificar")) {
			String proyecto = Proyecto4.getText();
			
			Proyecto elProyecto = controladorProyectos.getProyectos(proyecto);
			
			if (elProyecto != null)
			{
				
				ventana.getContentPane().removeAll();
				
				String text = "Se ha encontrado el proyecto exitosamente";
				ArrayList<String> lista = controladorProyectos.getActividades(proyecto);
				try {
					ArrayList<String> lista2 = controladorProyectos.getTareas(proyecto);
					strAr4=new String[lista2.size()];
					for (int i = 0; i < strAr4.length; i++) {
						strAr4[i] = lista2.get(i);
					}		
					Tarea1 = new javax.swing.JComboBox<String>(strAr4);
					
			
				}
				catch(NullPointerException e1){
					text = "No hay tareas asociadas al proyecto  ";
					Tarea1 = new javax.swing.JComboBox<String>(new String[] {"Sin tareas"});
				}
				
				
			
				strAr3 = new String[lista.size()];
				for (int i = 0; i < strAr3.length; i++) {
					strAr3[i] = lista.get(i);
				}
				
				

				Tipo4 = new javax.swing.JComboBox<String>(strAr3);
				
				JLabel actividad4 = new JLabel("Nombre Actividad:");
				JLabel participante4 = new JLabel("Participante:");
				JLabel descripcion4 = new JLabel("Descripcion:");
				JLabel tipo4 = new JLabel("Tipo:");
				JLabel info4 = new JLabel("Iniciar Actividad");
				JLabel info44 = new JLabel(text);
				JLabel tarea1 = new JLabel("Tarea:");
				
				Font font4 = new Font("MS Sans Serif", Font.BOLD, 22);
				info4.setFont(font4);
	
				JButton boton4 = new JButton("Iniciar");
				boton4.addActionListener(this);
	
				JButton boton44 = new JButton("Verificar");
				boton44.addActionListener(this);
	
				GridBagConstraints constraints4 = new GridBagConstraints();
				constraints4.anchor = GridBagConstraints.FIRST_LINE_END;
				constraints4.insets = new Insets(10, 10, 10, 10);
	
				constraints4.gridx = 1;
				constraints4.gridy = 0;
				constraints4.anchor = GridBagConstraints.CENTER;
				panel41.add(info4, constraints4);
	
				constraints4.gridx = 1;
				constraints4.gridy = 4;
				panel41.add(Actividad4, constraints4);
	
				constraints4.gridx = 0;
				constraints4.gridy = 4;
				panel41.add(actividad4, constraints4);
	
				constraints4.gridx = 1;
				constraints4.gridy = 5;
				panel41.add(Participante4, constraints4);
	
				constraints4.gridx = 0;
				constraints4.gridy = 5;
				panel41.add(participante4, constraints4);
	
				constraints4.gridx = 1;
				constraints4.gridy = 6;
				panel41.add(Descripcion4, constraints4);
	
				constraints4.gridx = 0;
				constraints4.gridy = 6;
				panel41.add(descripcion4, constraints4);
	
				constraints4.gridx = 1;
				constraints4.gridy = 7;
				constraints4.anchor = GridBagConstraints.CENTER;
				panel41.add(Tipo4, constraints4);
	
				constraints4.gridx = 0;
				constraints4.gridy = 7;
				panel41.add(tipo4, constraints4);
				
				constraints4.gridx = 1;
				constraints4.gridy = 8;
				constraints4.anchor = GridBagConstraints.CENTER;
				panel41.add(Tarea1, constraints4);
	
				constraints4.gridx = 0;
				constraints4.gridy = 8;
				panel41.add(tarea1, constraints4);
	
				constraints4.gridx = 0;
				constraints4.gridy = 3;
				constraints4.gridwidth = 2;
				constraints4.anchor = GridBagConstraints.CENTER;
				panel41.add(info44, constraints4);
	
				constraints4.gridx = 0;
				constraints4.gridy = 9;
				constraints4.gridwidth = 2;
				constraints4.anchor = GridBagConstraints.CENTER;
	
				panel41.add(boton4, constraints4);
	
				Proyecto4.setText("");
				ventana.getContentPane().add(panel41, BorderLayout.CENTER);
				ventana.getContentPane().add(this, BorderLayout.WEST);
				ventana.getContentPane().revalidate();
				ventana.getContentPane().repaint();

			}
			else {
				
				ventana.getContentPane().removeAll();
				
				Tipo4 = new javax.swing.JComboBox<String>(new String[] {"Opciones..."});
				Tarea1 = new javax.swing.JComboBox<String>(new String[] {"Opciones..."});

				JLabel error = new JLabel("-El proyecto no existe-");
				JLabel proyecto4 = new JLabel("Nombre proyecto:");
				JLabel actividad4 = new JLabel("Nombre Actividad:");
				JLabel participante4 = new JLabel("Participante:");
				JLabel descripcion4 = new JLabel("Descripcion:");
				JLabel tipo4 = new JLabel("Tipo:");
				JLabel tarea1 = new JLabel("Tarea:");

				JLabel info4 = new JLabel("Iniciar Actividad");

				Font font4 = new Font("MS Sans Serif", Font.BOLD, 22);
				info4.setFont(font4);

				JButton boton4 = new JButton("Iniciar");
				boton4.addActionListener(this);

				JButton boton44 = new JButton("Verificar");
				boton44.addActionListener(this);

				GridBagConstraints constraints4 = new GridBagConstraints();
				constraints4.anchor = GridBagConstraints.FIRST_LINE_END;
				constraints4.insets = new Insets(10, 10, 10, 10);

				constraints4.gridx = 1;
				constraints4.gridy = 0;
				constraints4.anchor = GridBagConstraints.CENTER;
				panel42.add(info4, constraints4);

				constraints4.gridx = 1;
				constraints4.gridy = 1;
				constraints4.anchor = GridBagConstraints.CENTER;
				panel42.add(error, constraints4);
				
				constraints4.gridx = 0;
				constraints4.gridy = 2;
				panel42.add(proyecto4, constraints4);

				constraints4.gridx = 1;
				constraints4.gridy = 2;
				panel42.add(Proyecto4, constraints4);

				constraints4.gridx = 1;
				constraints4.gridy = 5;
				panel42.add(Actividad4, constraints4);

				constraints4.gridx = 0;
				constraints4.gridy = 5;
				panel42.add(actividad4, constraints4);

				constraints4.gridx = 1;
				constraints4.gridy = 6;
				panel42.add(Participante4, constraints4);

				constraints4.gridx = 0;
				constraints4.gridy = 6;
				panel42.add(participante4, constraints4);

				constraints4.gridx = 1;
				constraints4.gridy = 7;
				panel42.add(Descripcion4, constraints4);

				constraints4.gridx = 0;
				constraints4.gridy = 7;
				panel42.add(descripcion4, constraints4);

				constraints4.gridx = 1;
				constraints4.gridy = 8;
				constraints4.anchor = GridBagConstraints.CENTER;
				panel42.add(Tipo4, constraints4);
				
				constraints4.gridx = 0;
				constraints4.gridy = 8;
				panel42.add(tipo4, constraints4);
				
				constraints4.gridx = 1;
				constraints4.gridy = 9;
				constraints4.anchor = GridBagConstraints.CENTER;
				panel42.add(Tarea1, constraints4);
				
				constraints4.gridx = 0;
				constraints4.gridy = 9;
				panel42.add(tarea1, constraints4);

				constraints4.gridx = 0;
				constraints4.gridy = 4;
				constraints4.gridwidth = 2;
				constraints4.anchor = GridBagConstraints.CENTER;
				panel42.add(boton44, constraints4);
				
				constraints4.gridx = 0;
				constraints4.gridy = 10;
				constraints4.gridwidth = 2;
				constraints4.anchor = GridBagConstraints.CENTER;
				panel42.add(boton4, constraints4);

				ventana.getContentPane().add(panel42, BorderLayout.CENTER);
				ventana.getContentPane().add(this, BorderLayout.WEST);
				ventana.getContentPane().revalidate();
				ventana.getContentPane().repaint();
			}
		}
		else if (event.equals("Iniciar")) {
			String proy = Proyecto4.getText();
			String part = Participante4.getText();
			String descripcion = Descripcion4.getText();
			String nombre = Actividad4.getText();
			String EleccionAct = (String) Tipo4.getSelectedItem();
			String Tarea = (String) Tarea1.getSelectedItem();
			
			tiempo = controladorProyectos.IniciarActividad(proy,nombre,part, descripcion, EleccionAct,Tarea);
			Proyecto4.setText(null);
			Participante4.setText(null);
			Descripcion4.setText(null);
			Actividad4.setText(null);
			Tipo4.setSelectedItem(null);
			Tarea1.setSelectedItem(null);
						
		}
		
		else if (event.equals("Verificar ")) {
			
			String proyecto = Proyecto5.getText();
					
			Proyecto elProyecto = controladorProyectos.getProyectos(proyecto);
			if (elProyecto != null)
			{
				
				String text = "Se ha encontrado el proyecto exitosamente";
				ArrayList<String> lista = controladorProyectos.getActividades(proyecto);
				ventana.getContentPane().removeAll();
			
				try {
					ArrayList<String> lista2 = controladorProyectos.getTareas(proyecto);
					strAr4=new String[lista2.size()];
					for (int i = 0; i < strAr4.length; i++) {
						strAr4[i] = lista2.get(i);
					}		
					Tarea2 = new javax.swing.JComboBox<String>(strAr4);
					
			
				}
				catch(NullPointerException e1){
					text = "No hay tareas asociadas al proyecto  ";
					Tarea2 = new javax.swing.JComboBox<String>(new String[] {"Sin tareas"});
				}
				
				strAr3 = new String[lista.size()];
				for (int i = 0; i < strAr3.length; i++) {
					strAr3[i] = lista.get(i);
				}
				
				Tipo5 = new javax.swing.JComboBox<String>(strAr3 );		
				
				enableDefaultValue(HoraFin, "HH:mm");
				enableDefaultValue(HoraInicio, "HH:mm");
				enableDefaultValue(FechaIn5, "dd-MM-yyyy");
				enableDefaultValue(FechaFin5, "dd-MM-yyyy");
				JLabel actividad5 = new JLabel("Nombre Actividad:");
				JLabel participante5 = new JLabel("Participante:");
				JLabel descripcion5 = new JLabel("Descripcion:");
				JLabel fechain5 = new JLabel("Fecha Inicio:");
				JLabel fechafin5 = new JLabel("Fecha Fin:");
				JLabel horain = new JLabel("Hora Inicio:");
				JLabel horafin = new JLabel("Hora Fin:");
				JLabel tipo5 = new JLabel("Tipo:");
				JLabel tarea2= new JLabel("Tarea:");
				JLabel info55 = new JLabel(text);


				JLabel info5 = new JLabel("Registar Actividad");

				Font font5 = new Font("MS Sans Serif", Font.BOLD, 22);
				info5.setFont(font5);

				JButton boton5 = new JButton("Registrar  ");
				boton5.addActionListener(this);

				GridBagConstraints constraints5 = new GridBagConstraints();
				constraints5.anchor = GridBagConstraints.FIRST_LINE_END;
				constraints5.insets = new Insets(10, 10, 10, 10);

				constraints5.gridx = 1;
				constraints5.gridy = 0;
				constraints5.anchor = GridBagConstraints.CENTER;
				panel51.add(info5, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 1;
				constraints5.anchor = GridBagConstraints.CENTER;
				panel51.add(info55, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 4;
				panel51.add(Actividad5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 4;
				panel51.add(actividad5, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 5;
				panel51.add(Participante5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 5;
				panel51.add(participante5, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 6;
				panel51.add(Descripcion5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 6;
				panel51.add(descripcion5, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 7;
				constraints5.anchor = GridBagConstraints.CENTER;
				panel51.add(Tipo5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 7;
				panel51.add(tipo5, constraints5);
				
				constraints5.gridx = 1;
				constraints5.gridy = 8;
				panel51.add(FechaIn5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 8;
				panel51.add(fechain5, constraints5);
				constraints5.gridx = 1;
				constraints5.gridy = 9;
				panel51.add(FechaFin5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 9;
				panel51.add(fechafin5, constraints5);
				
				constraints5.gridx = 1;
				constraints5.gridy = 10;
				panel51.add(HoraInicio, constraints5);
				constraints5.gridx = 0;
				constraints5.gridy = 10;
				panel51.add(horain, constraints5);
				constraints5.gridx = 0;
				constraints5.gridy = 11;
				panel51.add(horafin, constraints5);
				constraints5.gridx = 1;
				constraints5.gridy = 11;
				panel51.add(HoraFin, constraints5);

				
				constraints5.gridx = 1;
				constraints5.gridy = 12;
				constraints5.anchor = GridBagConstraints.CENTER;
				panel51.add(Tarea2, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 12;
				panel51.add(tarea2, constraints5);
				
				constraints5.gridx = 0;
				constraints5.gridy = 13;
				constraints5.gridwidth = 2;
				constraints5.anchor = GridBagConstraints.CENTER;

				panel51.add(boton5, constraints5);

				
				
				ventana.getContentPane().add(panel51, BorderLayout.CENTER);
				ventana.getContentPane().add(this, BorderLayout.WEST);
				ventana.getContentPane().revalidate();
				ventana.getContentPane().repaint();

				
				
			}
			else {
				ventana.getContentPane().removeAll();
				
				Tipo5 = new javax.swing.JComboBox<String>(new String[] {"Opciones..."});
				
				Tarea2 = new javax.swing.JComboBox<String>(new String[] {"Opciones..."});
				enableDefaultValue(HoraFin, "HH:mm");
				enableDefaultValue(HoraInicio, "HH:mm");
				enableDefaultValue(FechaIn5, "dd-MM-yyyy");
				enableDefaultValue(FechaFin5, "dd-MM-yyyy");

				JLabel proyecto5 = new JLabel("Nombre proyecto:");
				JLabel actividad5 = new JLabel("Nombre Actividad:");
				JLabel participante5 = new JLabel("Participante:");
				JLabel descripcion5 = new JLabel("Descripcion:");
				JLabel fechain5 = new JLabel("Fecha Inicio:");
				JLabel fechafin5 = new JLabel("Fecha Fin:");
				JLabel horain = new JLabel("Hora Inicio:");
				JLabel horafin = new JLabel("Hora Fin:");
				JLabel tipo5 = new JLabel("Tipo:");
				JLabel error = new JLabel("-El proyecto no existe-");
				JLabel tarea2 = new JLabel("Tarea:");

				JLabel info5 = new JLabel("Registar Actividad");

				Font font5 = new Font("MS Sans Serif", Font.BOLD, 22);
				info5.setFont(font5);

				JButton boton5 = new JButton("Registrar  ");
				boton5.addActionListener(this);

				JButton boton55 = new JButton("Verificar ");
				boton55.addActionListener(this);

				GridBagConstraints constraints5 = new GridBagConstraints();
				constraints5.anchor = GridBagConstraints.FIRST_LINE_END;
				constraints5.insets = new Insets(10, 10, 10, 10);

				constraints5.gridx = 1;
				constraints5.gridy = 0;
				constraints5.anchor = GridBagConstraints.CENTER;
				panel52.add(info5, constraints5);
				
				constraints5.gridx = 0;
				constraints5.gridy = 3;
				panel52.add(error, constraints5);


				constraints5.gridx = 0;
				constraints5.gridy = 1;
				panel52.add(proyecto5, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 1;
				panel52.add(Proyecto5, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 4;
				panel52.add(Actividad5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 4;
				panel52.add(actividad5, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 5;
				panel52.add(Participante5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 5;
				panel52.add(participante5, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 6;
				panel52.add(Descripcion5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 6;
				panel52.add(descripcion5, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 7;
				constraints5.anchor = GridBagConstraints.CENTER;
				panel52.add(Tipo5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 7;
				panel52.add(tipo5, constraints5);
				
				constraints5.gridx = 1;
				constraints5.gridy = 8;
				panel52.add(FechaIn5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 8;
				panel52.add(fechain5, constraints5);
				constraints5.gridx = 1;
				constraints5.gridy = 9;
				panel52.add(FechaFin5, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 9;
				panel52.add(fechafin5, constraints5);
				
				constraints5.gridx = 1;
				constraints5.gridy = 10;
				panel52.add(HoraInicio, constraints5);
				constraints5.gridx = 0;
				constraints5.gridy = 10;
				panel52.add(horain, constraints5);
				constraints5.gridx = 0;
				constraints5.gridy = 11;
				panel52.add(horafin, constraints5);
				constraints5.gridx = 1;
				constraints5.gridy = 11;
				panel52.add(HoraFin, constraints5);

				constraints5.gridx = 1;
				constraints5.gridy = 3;
				constraints5.gridwidth = 2;
				constraints5.anchor = GridBagConstraints.CENTER;
				
				constraints5.gridx = 1;
				constraints5.gridy = 12;
				constraints5.anchor = GridBagConstraints.CENTER;
				panel52.add(Tarea2, constraints5);

				constraints5.gridx = 0;
				constraints5.gridy = 12;
				panel52.add(tarea2, constraints5);

				panel52.add(boton55, constraints5);
				constraints5.gridx = 0;
				constraints5.gridy = 13;
				constraints5.gridwidth = 2;
				constraints5.anchor = GridBagConstraints.CENTER;

				panel52.add(boton5, constraints5);

				
				
				ventana.getContentPane().add(panel52, BorderLayout.CENTER);
				ventana.getContentPane().add(this, BorderLayout.WEST);
				ventana.getContentPane().revalidate();
				ventana.getContentPane().repaint();
			}

		}
		else if (event.equals("Registrar  ")) {
			
			String proy = Proyecto5.getText();
			String activ=Actividad5.getText();
			String part = Participante5.getText();
			String descripcion = Descripcion5.getText();
			String fechain = FechaIn5.getText();
			String fechafin = FechaFin5.getText();
			String EleccionAct = (String) Tipo5.getSelectedItem();
			String horain = HoraInicio.getText();
			String horafin = HoraFin.getText();
			String tarea2 = (String) Tarea2.getSelectedItem();
			
			controladorProyectos.RegistrarActividad(proy,activ,part,descripcion,EleccionAct,fechain,fechafin,horain,horafin,tarea2);
			Proyecto5.setText(null);
			Participante5.setText(null);
			Descripcion5.setText(null);
			Actividad5.setText(null);
			FechaIn5.setText(null);
			FechaFin5.setText(null);
			HoraInicio.setText(null);
			HoraFin.setText(null);
			Tipo5.setSelectedItem(null);
			Tarea2.setSelectedItem(null);

			
		}
		else if (event.equals("Finalizar actividad en curso")) {
			controladorProyectos.FinalizarActividad(tiempo);
		
		}
		
		
		else if (event.equals("Visualizaciones")) {
			
			JButton Boton1 = new JButton("Porcentaje de Avance");
			JButton Boton2 = new JButton("Calidad de planeacion");
			JButton Boton3 = new JButton("Equipo");
			JButton Boton4 = new JButton("Boton4");
			
			JLabel p = new JLabel("Proyecto");
			JLabel u = new JLabel("Participante");
			
			Boton1.addActionListener(this);
			Boton2.addActionListener(this);
			Boton3.addActionListener(this);
			Boton4.addActionListener(this);


			GridBagConstraints constraints11 = new GridBagConstraints();
			constraints11.anchor = GridBagConstraints.FIRST_LINE_END;
			constraints11.insets = new Insets(10, 10, 10, 10);

			constraints11.gridx = 0;
			constraints11.gridy = 0;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel11.add(p, constraints11);
			
			constraints11.gridx = 1;
			constraints11.gridy = 0;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel11.add(Proyecto321, constraints11);
			
			constraints11.gridx = 1;
			constraints11.gridy = 1;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel11.add(Boton1, constraints11);
			
			constraints11.gridx = 1;
			constraints11.gridy = 2;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel11.add(Boton2, constraints11);
			
			constraints11.gridx = 1;
			constraints11.gridy = 3;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel11.add(Boton3, constraints11);
			
			constraints11.gridx = 1;
			constraints11.gridy = 4;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel11.add(Boton4, constraints11);
			
			constraints11.gridx = 0;
			constraints11.gridy = 5;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel11.add(u, constraints11);
			
			constraints11.gridx = 1;
			constraints11.gridy = 5;
			constraints11.anchor = GridBagConstraints.CENTER;
			panel11.add(Participante321, constraints11);
			
			ventana.getContentPane().removeAll();
			ventana.getContentPane().add(panel11, BorderLayout.CENTER);
			ventana.getContentPane().add(this, BorderLayout.WEST);
			ventana.getContentPane().revalidate();
			ventana.getContentPane().repaint();
			
		}
		
		
		
		else if(event.equals("Finalizar proyecto")) {
			
			String nombre=Nombre7.getText();
			controladorProyectos.FinalizarProyecto(nombre);
			Nombre7.setText(null);
			
		}
		
		else if(event.equals("Porcentaje de Avance")) {
			
			String proy = Proyecto321.getText();
			Proyecto p1 = controladorProyectos.getProyectos(proy);
			ArrayList<String> a = p1.getTareas();
			int cant = a.size();
			
			HashMap<String, Actividad> t = p1.getActividades();
			int cant2 = t.size();
			
			System.out.println(cant);
			System.out.println(cant2);

			double porc=((double)cant2/(double)cant)*100;
			System.out.println(porc);
			
	        JFrame f = new JFrame("Avance del proyecto");
	 
	        JPanel p = new JPanel(new BorderLayout());   
	        
	        JProgressBar b = new JProgressBar();
	 
	        b.setForeground(Color.GREEN);
	        
	        b.setValue((int)porc);
	 
	        b.setStringPainted(true);
	 
	        p.add(b);
	 
	        f.add(p,BorderLayout.CENTER);
	 
	        f.setSize(500, 200);
	        
	        f.setVisible(true);
	        
	        }
	    
	
		else if(event.equals("Calidad de planeacion")) {
			
			String proy = Proyecto321.getText();
			Proyecto p = controladorProyectos.getProyectos(proy);
			ArrayList<String> a = p.getTareas();
			int cant = a.size();
			
			HashMap<String, Actividad> t = p.getActividades();
			int cant2 = t.size();
			
			double porc=(double)cant2/(double)cant;
		
			JFrame f = new JFrame();

			DialChart g = Graficador.getChart(proy, porc);
			
			JPanel chartP = new XChartPanel<DialChart>(g);
			f.add(chartP,BorderLayout.CENTER);
			f.pack();
			f.setVisible(true);
			
			
		}
		
		
		else if(event.equals("Equipo")) {
			JFrame f = new JFrame();
			PieChart p =  Graficador.donut();
			
			JPanel chartP = new XChartPanel<PieChart>(p);
			f.add(chartP,BorderLayout.CENTER);
			f.pack();
			f.setVisible(true);
			
		}
		else if(event.equals("Generar")) {
			String nombre=Participante8.getText();
			controladorProyectos.GenerarReporte(nombre);
			Participante8.setText(null);
			
			controladorProyectos.GenerarPastel(nombre);
			
			 JFrame frame = new JFrame();
		      frame.getContentPane().add(new MyComponent());
		      frame.setSize(300, 300);
		      frame.setVisible(true);

			}
		}

	
		class MyComponent extends JComponent {			
			CreadorPastel x = controladorProyectos.darCreador();
		   Slice[] slices = x.darSlices();
		   MyComponent() {}
		   public void paint(Graphics g) {
		      drawPie((Graphics2D) g, getBounds(), slices);
		   }
		   void drawPie(Graphics2D g, Rectangle area, Slice[] slices) {
		      double total = 0.0D;
	
		      for (int i = 0; i < slices.length; i++) {
		    	  if (slices[i] == null) {
		    		  break;
		    	  }
		         total += slices[i].value;
		      }
		      double curValue = 0.0D;
		      int startAngle = 0;
		      
		      for (int i = 0; i < slices.length; i++) {
		    	  if (slices[i] == null) {
		    		  break;
		    	  }
		         startAngle = (int) (curValue * 360 / total);
		         int arcAngle = (int) (slices[i].value * 360 / total);
		         g.setColor(slices[i].color);
		         g.fillArc(area.x, area.y, area.width, area.height, startAngle, arcAngle);
		         curValue += slices[i].value;
		      }
		   }
		}

		
		public static void enableDefaultValue(final JTextField tf, final String defaultValue) {
			tf.setText(defaultValue);
			tf.setForeground(Color.gray);	
			
			tf.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				if (tf.getText().equals(defaultValue)) {
					tf.setForeground(Color.black);
					tf.setText("");
				}
				super.focusGained(e);
			}
			
			

			@Override
			public void focusLost(FocusEvent e) {
				if (tf.getText().equals("")) {
					tf.setForeground(Color.gray);
					tf.setText(defaultValue);
				}
				super.focusLost(e);
			}
			});
		}
		
}
