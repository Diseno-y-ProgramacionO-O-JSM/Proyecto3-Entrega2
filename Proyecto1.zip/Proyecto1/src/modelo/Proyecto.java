package modelo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class Proyecto {
	
	private String nombre;
	private String descripcion;
	private Participante due�o; //Queda por defecto
	private ArrayList<Participante> participantes=new ArrayList<Participante>();
	private String fechain;
	private String fechafin;
	private ArrayList<String> tipos=new ArrayList<String>();
	private HashMap<String,Actividad> actividades=new HashMap<>();
	private ArrayList<String> tareas=new ArrayList<String>();
	private WBS w;
	
	public Proyecto(String nombre1,String descripcion1, Participante due�o1, String correo, String fechain1, String fechafin1,ArrayList<String> tipos1)
	{
		this.nombre = nombre1;
		this.descripcion = descripcion1;
		this.due�o=due�o1;
		this.fechain = fechain1;
		this.fechafin = fechafin1;
		this.tipos = tipos1;
		this.participantes = new ArrayList<Participante>();
		this.actividades = new HashMap<String,Actividad>();
		this.w = new WBS(nombre1);
	}
	
	
	
	public String getNombre() {
		return nombre;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public Participante getDue�o() {
		return due�o;
	}
	
	public String getfechain() {
		return fechain;
	}
	
	public String getfechafin() {
		return fechafin;
	}
	
	public ArrayList<String> getTiposActividades() {
		return tipos;
	}
	
	public HashMap<String,Actividad> getActividades() {
		return actividades;
	}
	
	public ArrayList<String> getTareas() {
		return tareas;
	}
	
	public void addTarea(String tarea) {
		tareas.add(tarea);
	}
	
	public ArrayList<Participante> getParticipantes() {
		return participantes;								
	}
	
	public void AgregarParticipantes( Participante participante) {////
		participantes.add(participante);
	}
	
	public void FechaFinal() {
		String pattern = "dd-MM-yyyy";
		String fechafinal = new SimpleDateFormat(pattern).format(new Date());
		fechafin = fechafinal;
	}
	
	public WBS getWBS() {
		return w;
	}
	
	
	
	
	
	
	
}
