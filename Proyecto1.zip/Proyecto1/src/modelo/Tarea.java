package modelo;

import java.util.ArrayList;

public class Tarea {
	private String Nombre;
	private String Descripcion;
	private String Importancia;
	private String FechaEstimadaFin;
	private ArrayList<Actividad> actividades=new ArrayList<Actividad>();
	private ArrayList<Participante> responsables=new ArrayList<Participante>();
	
	
	
	public Tarea(String Nombre, String Descripcion, String Importancia) {
		this.Nombre = Nombre;
		this.Descripcion = Descripcion;
		this.Importancia = Importancia;
	}
	
	public String getNombre() {
		return Nombre;
	}
	public String getDescripcion() {
		return Descripcion;
	}
	public String getImportancia() {
		return Importancia;
	}
	public String getFechaEstimadaFin() {
		return FechaEstimadaFin;
	}
	public ArrayList<Participante> getResponsables() {
		return responsables;
	}
	public void addResponsable(Participante participante){
		responsables.add(participante);
	}
	public void addActividad(Actividad actividad) {
		actividades.add(actividad);
	}
	

}
