package modelo;

import java.util.ArrayList;
import java.util.HashMap;

public class WBS {
	
	private String Nombre;
	private HashMap<String,Tarea> tareasAlta= new HashMap<>();
	private HashMap<String,Tarea> tareasMedia= new HashMap<>();
	private HashMap<String,Tarea> tareasBaja= new HashMap<>();
	private HashMap<String,Tarea> tareas= new HashMap<>();
	private HashMap<String,Paquete> paquetes= new HashMap<>();
	
	public WBS(String nombre) {
		this.Nombre = nombre;
		this.tareasAlta = new HashMap<String,Tarea>();
		this.tareasMedia = new HashMap<String,Tarea>();
		this.tareasBaja = new HashMap<String,Tarea>();
		this.paquetes = new HashMap<String,Paquete>();
	}
	
	public Tarea crearTarea(String Nombre, String Descripcion, String Importancia) {
		Tarea tarea= new Tarea(Nombre,  Descripcion,  Importancia);
		if (Importancia=="Alta") {
			tareasAlta.put(Nombre, tarea);
		}
		else if(Importancia=="Media"){
			tareasMedia.put(Nombre, tarea);
		}
		else if (Importancia =="Baja") {
			tareasAlta.put(Nombre, tarea);
		}
		tareas.put(Nombre, tarea);
		return tarea;
	}
	public void crearPaquete(String Nombre, String Descripcion) {
		Paquete paquete = new Paquete( Nombre, Descripcion);
		paquetes.put(Nombre, paquete);
	}
	
	public void addTPaquete(String paquete, ArrayList<String> listatareas) {
		Boolean existen = true;
		ArrayList<Tarea> empaquetar = new ArrayList<Tarea>();
		
		Paquete Paq = paquetes.get(paquete);
		for(int i = 0; i < listatareas.size(); i++) {
			
			String t = listatareas.get(i);
			Tarea tarea = tareasBaja.get(t);		
			if (tarea == null) {			
				tarea = tareasMedia.get(t);
				if (tarea == null) {
					tarea = tareasAlta.get(t);	
					if (tarea == null) {
						existen = false;
					}
					else {
						empaquetar.add(tarea);
					}
				}
				else {
					empaquetar.add(tarea);
				}		
			}
			else {
				empaquetar.add(tarea);
			}
		}
		
		if (Paq != null && existen==true) {
			Paq.addTareas(empaquetar);
		}
		else {
			System.out.println("El paquete o alguna de las tareas no existe");
		}
		
	}
	
	public void addResponsable(String tarea,Participante participante) {
		Tarea tar = tareas.get(tarea);
		tar.addResponsable(participante);
		
	}
	
	public void deleteTarea(String tarea) {
		tareas.remove(tarea);
		
		Tarea tare = tareasBaja.get(tarea);		
		if (tare == null) {			
			tare = tareasMedia.get(tarea);
			if (tare == null) {
				tare = tareasAlta.get(tarea);	
				if (tare != null) {
					 tareasAlta.remove(tarea);
				}
			}
			else {
				 tareasMedia.remove(tarea);
			}		
		}
		else {
			 tareasBaja.remove(tarea);
		}
	}
	
	
	public void organizarTareas(Proyecto proyecto) {
		
	}

	public void ActividadTarea(Tarea tarea, Actividad actividad) {
		
	}
}
