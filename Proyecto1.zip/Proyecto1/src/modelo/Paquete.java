package modelo;

import java.util.ArrayList;
import java.util.HashMap;

public class Paquete {
	private String Nombre;
	private String Descripcion;
	private HashMap<String,Tarea> tareas=new HashMap<>();
	
	
	
	public Paquete(String nombre, String descripcion) {
		
		this.Nombre = nombre;
		this.Descripcion = descripcion;
		
	}
	
	public String getNombre() {
		return Nombre;
	}
	public String getDescripcion() {
		return Descripcion;
	}
	public HashMap<String,Tarea> getTareas() {
		return tareas;
	
	}
	
	public void addTareas(ArrayList<Tarea> listatareas) {
		
		for(int i = 0; i < listatareas.size(); i++) {
			Tarea tarea = listatareas.get(i);
			String nombre = tarea.getNombre();
			tareas.put(nombre, tarea);
		
			
		}
	}
	
	
	

}
