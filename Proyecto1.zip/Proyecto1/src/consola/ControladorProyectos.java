package consola;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

import modelo.Actividad;
import modelo.Participante;
import modelo.Proyecto;
import modelo.Tarea;
import modelo.WBS;
import procesamiento.CreadorPastel;
import procesamiento.CreadorTxt;

public class ControladorProyectos {

		HashMap<String, Participante> participantes = new HashMap<>();
		HashMap<String, Proyecto> proyectos = new HashMap<>();
		HashMap<String, Tarea> tareas = new HashMap<>();
		HashMap<String, String> TareaProyecto = new HashMap<>();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		Actividad actividad = null;
		ArrayList<Integer> ListaAbreYCierra = new ArrayList<>();
		CreadorPastel c = new CreadorPastel();
			
			public void RegistroUsuario(String nombre,String correo) {
				
				Random numAleatorio = new Random();
				int id = numAleatorio.nextInt(1000) + 1;
				
				Participante elParticipante = participantes.get(nombre);
				if (elParticipante == null);
					elParticipante = new Participante(nombre, correo, id);
					participantes.put(nombre, elParticipante);
				
			}
			
			public HashMap<String, Tarea> getTareas(){
				return tareas;
			}
			
			public void CrearProyecto(String nombre,String due�o,String descripcion,String tiposs) {
				//Por defecto el que cre� el proyecto queda como due�o
				
					
				Proyecto elProyecto = proyectos.get(nombre);
				if (elProyecto == null)
				{
					
					Participante elParticipante = participantes.get(due�o);
					if (elParticipante == null) {
						System.out.println("No se ha registrado como usuario el participante");}
					else {
						String correo = elParticipante.getCorreo();
						String pattern = "dd-MM-yyyy";
						String fechain = new SimpleDateFormat(pattern).format(new Date());
						String fechafin = null; //Finalizar proyecto						
						
						ArrayList<String> tipos = new ArrayList<String>(Arrays.asList(tiposs.split(",")));					
						
						elProyecto = new Proyecto(nombre, descripcion, elParticipante, correo, fechain, fechafin, tipos);				
						proyectos.put(nombre, elProyecto);
						
						elProyecto.AgregarParticipantes(elParticipante);
						
						new WBS(nombre);
						
					}		
				}
				else {
					Participante dueno = elProyecto.getDue�o();
					System.out.println("-Ya existe un proyecto con ese nombre creado por "+ dueno.toString()+"-");
				}
				}
			
			public Instant IniciarActividad(String proy,String nombre,String part,String descripcion,String tipo,String Tarea){
				//Puede ser a nombre de cualquier persona

				
				Proyecto elProyecto = proyectos.get(proy);
				
				if (elProyecto == null) {
					System.out.println("El proyecto no existe");
					}
				else {
					
					HashMap<String, Actividad> map = elProyecto.getActividades();
					Actividad laActividad = map.get(nombre);
					if (laActividad == null) {
					
						Participante elParticipante = participantes.get(part);
						if (elParticipante == null) {
							System.out.println("No se ha registrado como usuario el participante");
							}
						else {
							System.out.println("Elija un tipo de actividad:");
							
							ArrayList<String> Listita =elProyecto.getTiposActividades();
							
					     
							String pattern = "dd-MM-yyyy";
							String fechain = new SimpleDateFormat(pattern).format(new Date());
							String fechafin = null;
							String horain = LocalTime.now().format(formatter);
							String horafin = null;
							
							Tarea tarea = tareas.get(Tarea);
							if (tarea != null) {
								
								laActividad = new Actividad(nombre, descripcion, tipo, fechain, fechafin, horain,horafin,elParticipante, elProyecto,tarea);
								actividad = laActividad;
								map.put(nombre,laActividad);
								elParticipante.agregarActividad(laActividad);
							}
							else {
								System.out.println("La tarea a la que se e va a asignar la actividad no se ha creado aun");
							}
						}
					}
					else {
						
						Participante participante = laActividad.getParticipante();
						String part2 = participante.getNombre();
						if (part.equals(part2)){
							String pattern = "dd-MM-yyyy";
							String fechain = new SimpleDateFormat(pattern).format(new Date());
							laActividad.newFechaIn(fechain);
							String fechafin = null;
							laActividad.newFechaFin(fechafin);
							String horain = LocalTime.now().format(formatter);
							laActividad.newHoraIn(horain);
							String horafin = null;
							laActividad.newHoraFin(horafin);
							actividad = laActividad;
						}
						else {
							System.out.println("El participante que est� realizando esta actividad es otro.");
						}						
					}
				}
			
				Instant Inicial= Actividad.IniciarCronometro();
				return Inicial;			
				}
			
			public void AgregarParticipante(String proy,String part){
				
				
				Proyecto elProyecto = proyectos.get(proy);
				
				if (elProyecto == null) {
					System.out.println("El proyecto no existe");
					}
				else {
					
					Participante elParticipante = participantes.get(part);
					if (elParticipante == null) {
						System.out.println("No se ha registrado como usuario el participante");
						}
					else {
						Boolean presente = false;
						ArrayList<Participante> participantes = elProyecto.getParticipantes();
						for (int i=0;i<participantes.size();i++) {
							String par = participantes.get(i).getNombre();
							String par1 = elParticipante.getNombre();
							if (par.equals(par1)){
								presente = true;
								System.out.println("El usuario ya es participante de este proyecto");
							}
						}
						if (!presente) {
							elProyecto.AgregarParticipantes(elParticipante);
							}
						}
					}
				
				}
		
			public void RegistrarActividad(String proy,String nombre,String part,String descripcion,String tipo,String fechain,String fechafin,String horain,String horafin, String Tarea) {
				
				
				Proyecto elProyecto = proyectos.get(proy);
				
				if (elProyecto == null) {
					System.out.println("El proyecto no existe");
					}
				else {
					
					HashMap<String, Actividad> map = elProyecto.getActividades();
					Actividad laActividad = map.get(nombre);
					if (laActividad == null) {
						
						
						Participante elParticipante = participantes.get(part);
						if (elParticipante == null) {
							System.out.println("No se ha registrado como usuario el participante");
							}
						else {
						
							System.out.println("Elija un tipo de actividad:");
							
							ArrayList<String> Listita =elProyecto.getTiposActividades();
							
							
							for(int i = 0; i < Listita.size(); i++) {
					            System.out.println((i+1) + ": " +Listita.get(i));
					        }
					        
							
								Tarea t = tareas.get(Tarea);
					        	
					        	if (t!=null) {
								laActividad = new Actividad(nombre, descripcion, tipo, fechain, fechafin, horain,horafin,elParticipante, elProyecto, t);
								map.put(nombre,laActividad);
								
								laActividad.getTiempoTotal(laActividad.getFecha(),laActividad.getHoraInicio(),laActividad.getFechaFin(),laActividad.getHoraFin());
								elParticipante.agregarActividad(laActividad);
								
					        	}
						}
						
					}
					else {
					
						Participante participante = laActividad.getParticipante();
						String part2 = participante.getNombre();
						if (part.equals(part2)){

									
							laActividad.newFechaIn(fechain);
							laActividad.newFechaFin(fechafin);
							laActividad.newHoraIn(horain);
							laActividad.newHoraFin(horafin);
							
							laActividad.getTiempoTotal(laActividad.getFecha(),laActividad.getHoraInicio(),laActividad.getFechaFin(),laActividad.getHoraFin());
							
						}
						else {
							
							System.out.println("El participante que est� realizando esta actividad es otro.");
						}
					}
				}
				
		        
				
				}

			public Proyecto getProyectos(String proy) {
				
				
				Proyecto elProyecto = proyectos.get(proy);
				if (elProyecto != null) {
				return elProyecto;
				}
				else {
					return null;
				}
			}
			
			public ArrayList<String> getActividades(String proy) {
				Proyecto elProyecto = proyectos.get(proy);
				ArrayList<String> Listita =elProyecto.getTiposActividades();
				return Listita;
			}
			
			public ArrayList<String> getTareas(String proy) {
				Proyecto elProyecto = proyectos.get(proy);
				ArrayList<String> Listita =elProyecto.getTareas();
				return Listita;
			}
			
			public void FinalizarActividad(Instant HoraIn) {
				
				String pattern = "dd-MM-yyyy";
				String fechafin = new SimpleDateFormat(pattern).format(new Date());
				String horafin = LocalTime.now().format(formatter);				
				actividad.newFechaFin(fechafin);
				actividad.newHoraFin(horafin);
				actividad.getTiempoTotal(actividad.getFecha(),actividad.getHoraInicio(),actividad.getFechaFin(),actividad.getHoraFin());
				
				
			}
			
			public void FinalizarProyecto(String proy) {
				
				
				Proyecto elProyecto = proyectos.get(proy);
				
				if (elProyecto == null) {
					System.out.println("El proyecto no existe");
					}
				else {
					elProyecto.FechaFinal();
					CreadorTxt.txtProyecto(elProyecto);
					}		
				}
			
			
			public void GenerarReporte(String part) {
	
					Participante elParticipante = participantes.get(part);
					if (elParticipante == null) {
						System.out.println("No se ha registrado como usuario el participante");
						}
					else {
						CreadorTxt.txtParticipante(elParticipante);
						System.out.println("Se Ha Generado El Reporte");
					}		
			}
			
			public void CrearTarea(String tarea, String proyecto, String descripcion, String importancia) {
				
				Proyecto elProyecto = proyectos.get(proyecto);
				
				if (elProyecto != null) {
					WBS w = elProyecto.getWBS();
					
					Tarea t = w.crearTarea(tarea, descripcion, importancia);
					String proy = elProyecto.getNombre();
					TareaProyecto.put(tarea, proy);
					tareas.put(tarea,t);
					elProyecto.addTarea(tarea);

				}		
				
			}
			
			public void CrearPaquete(String nombre, String desc,String proy) {
				
				Proyecto elProyecto = proyectos.get(proy);
				WBS w = elProyecto.getWBS();
				if (elProyecto != null) {
					w.crearPaquete(nombre, desc);
					
					}	
				
				//////////////TRY
				
			}
			
			public void addTPaquete(String nombre, String tareas) {
				Boolean mismo = true;
				String proy = "";
				ArrayList<String> list = new ArrayList<String>(Arrays.asList(tareas.split(",")));
				for (int i = 0; i < list.size()-1; i++) {
		
					String tarea = list.get(i);
					String tarea2 = list.get(i+1);
					proy = TareaProyecto.get(tarea);
					String proy2 = TareaProyecto.get(tarea2);
					
					if (proy!=proy2) {
						mismo = false;
						System.out.println("Alguna tarea no pertenece al proyecto");		
					}
				}
					
				if (mismo) {
					Proyecto elProyecto = proyectos.get(proy);
					WBS w = elProyecto.getWBS();
					if (elProyecto != null) {								
						w.addTPaquete(nombre, list);
						}	
				}
			}
			
			public 	void addResponsable(String nombre, String tarea) {
				
				String proy = TareaProyecto.get(tarea);
				
				Proyecto elProyecto = proyectos.get(proy);
				
				Participante par = participantes.get(nombre);
				
				System.out.println(par);
				if (elProyecto != null) {
					WBS w = elProyecto.getWBS();
					w.addResponsable(tarea, par);
					}	
				
			}
			
			public void GenerarPastel(String part) {
				
				

				Participante elParticipante = participantes.get(part);
				if (elParticipante == null) {
					System.out.println("No se ha registrado como usuario el participante");
					}
				else {
					c.cargarActividades(elParticipante);
					System.out.println("Se Ha Generado El Grafico Pastel");}
				}
				
			public CreadorPastel darCreador() {
					return c;
				}
			
			public void delete(String tarea) {
				System.out.println(tarea);
				Boolean proy = TareaProyecto.isEmpty();
				String pro = TareaProyecto.get(tarea);
				System.out.println(proy);
				Proyecto proyecto = proyectos.get(pro);
				System.out.println(proyecto);

				WBS w = proyecto.getWBS();
				
				w.deleteTarea(tarea);
				TareaProyecto.remove(tarea);
				tareas.remove(tarea);
			}
			
			public void asignarFecha(String tarea,String fecha) {
				
			}
			
			public String input(String mensaje)
			{
				try
				{
					System.out.print(mensaje + ": ");
					BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
					return reader.readLine();
				}
				catch (IOException e)
				{
					System.out.println("Error leyendo de la consola");
					e.printStackTrace();
				}
				return null;
			}
			
			
			
			

}
